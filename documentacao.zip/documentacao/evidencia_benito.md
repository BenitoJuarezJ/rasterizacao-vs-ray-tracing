# Registro de Evidência de Contribuição Individual — Benito Juarez Jesus Viana Aguiar

**Curso / Disciplina:** Ciência da Computação / Computabilidade e Complexidade de Algoritmos  
**Projeto:** Análise Comparativa do Custo Computacional: Z-Buffer vs BVH (Ray Tracing)  
**Orientadora:** Andrea Ono Sakai  

---

## 1. Resumo da Contribuição (Etapa b)

* **Passos em que atuou:** Passo 3 (Bases de dados escolhidas), Passo 6 (Triagem por título e resumo) e Passo 7 (Triagem por leitura completa).
* **Descrição da atuação:** Fui responsável pela seleção e justificativa das bases científicas indexadas (IEEE Xplore, ACM DL e Scopus) e pela condução da triagem de referências utilizando o fluxo do método PRISMA no gerenciador Zotero. Realizei a filtragem de abstracts e a leitura completa para homologação dos 5 artigos finais.
* **Tempo dedicado:** ~4h

---

## 2. Detalhamento do Fluxo e Evidência Visual

### 2.1. Execução do Funil PRISMA (Zotero)
Para garatir a rastreabilidade exigida pela orientação, estruturei a triagem dentro do Zotero em três etapas sequenciais:
1. **Identificação e Deduplicação:** Importação da amostra bruta trazida pelas strings de busca e remoção de duplicatas entre as bases.
2. **Triagem de Título/Resumo (Passo 6):** Análise dos abstracts para descartar trabalhos focados unicamente em qualidade fotográfica ou direção de arte, retendo os focados em complexidade e tempo de execução.
3. **Inclusão Definitiva (Passo 7):** Homologação dos 5 artigos revisados por pares com DOI confirmado que compõem o repositório.

### 2.2. Comprovação Visual
A imagem `evidencia_prisma_benito.png`, armazenada no diretório `referencias/` deste repositório, exibe a estrutura de pastas do Zotero demonstrando a segregação dos artigos e os metadados validados do conjunto aprovado.

---

## 3. Conclusão
A aplicação da triagem PRISMA assegurou a eliminação de fontes cinzentas ou não rastreáveis, fornecendo uma base bibliográfica sólida e estritamente alinhada aos critérios da disciplina.