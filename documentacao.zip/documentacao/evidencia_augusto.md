# Registro de Evidência de Contribuição Individual — Augusto Domingues da Silva

**Curso / Disciplina:** Ciência da Computação / Computabilidade e Complexidade de Algoritmos  
**Projeto:** Análise Comparativa do Custo Computacional: Z-Buffer vs BVH (Ray Tracing)  
**Orientadora:** Andrea Ono Sakai  

---

## 1. Resumo da Contribuição (Etapa b)

* **Passos em que atuou:** Passo 4 (Critérios de inclusão e exclusão) e Passo 6 (Triagem por título e resumo).
* **Descrição da atuação:** Fui responsável por estruturar os bloqueios metodológicos ("hard stops") para garantir que apenas literatura científica revisada por pares compusesse o referencial teórico, eliminando as fontes inválidas apontadas na avaliação anterior. Conduzi a primeira filtragem (peneira fina) em lote e garanti a consolidação técnica e formatação dos artefatos Markdown exigidos pela disciplina.
* **Tempo dedicado:** ~3h

---

## 2. Detalhamento Técnico e Evidências

### 2.1. Aplicação dos "Hard Stops" (Passo 4)
Para mitigar os alertas levantados no "Parecer — Grupo 8", estabeleci regras estritas de exclusão no gerenciador de referências.
* **Filtros Aplicados:** Foram sumariamente rejeitados quaisquer Trabalhos de Conclusão de Curso (TCCs), dissertações sem publicação em periódicos, links de nuvem pessoal (`share.google`) e repositórios institucionais genéricos. 
* **Evidência:** O rigor metodológico está refletido na tabela "Lista Final de Artigos Selecionados" do Passo 3, que agora conta com 100% dos trabalhos provindos de *Journals* e conferências de alto impacto (IEEE e ACM).

### 2.2. Triagem em Lote (Passo 6)
* Após a importação de 431 artigos brutos para o Zotero, atuei na higienização da base. Removemos 42 duplicatas geradas pelo cruzamento das bases IEEE Xplore e Scopus.
* Avaliei os títulos e resumos descartando 340 artigos que, embora contivessem os termos "Ray Tracing" ou "Rasterização", focavam exclusivamente em qualidade estética, fotografia ou direção de arte, desviando do recorte algorítmico do projeto.

### 2.3. Formatação e Consolidação Markdown
* **Configuração Metodológica:** Padronizei a taxonomia dos arquivos exigidos para entrega (`a_Escolha_do_Tema.md`, `b_Levantamento_Bibliografico_Preliminar.md` e `c_objetivo_geral_e_especificos.md`), garantindo que não houvesse supressão de tabelas ou campos do template original da disciplina.
* **Evidência Física:** O histórico de *commits* da *branch* `main` no repositório do GitHub atesta a consolidação estrutural dos arquivos `.md`, bem como a correta linkagem da pasta de referências.

---

## 3. Conclusão da Etapa
As travas de qualidade aplicadas garantiram a rastreabilidade exigida pela orientação e elevaram o rigor científico da amostra, resultando em um banco de artigos apto para fichamento e análise de complexidade matemática.