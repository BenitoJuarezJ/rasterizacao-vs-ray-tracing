# Registro de Evidência de Contribuição Individual — Renan Vears de Andrade

**Curso / Disciplina:** Ciência da Computação / Computabilidade e Complexidade de Algoritmos  
**Projeto:** Análise Comparativa do Custo Computacional: Z-Buffer vs BVH (Ray Tracing)  
**Orientadora:** Andrea Ono Sakai  

---

## 1. Resumo da Contribuição (Etapa b)

* **Passos em que atuou:** Passo 2 (Strings de busca) e Passo 5 (Execução das buscas).
* **Descrição da atuação:** Fui responsável pela formulação lógica das strings de pesquisa utilizando operadores booleanos estruturados (AND, OR, aspas para termos compostos). Após a validação das strings, apliquei os parâmetros de busca avançada no acervo da **ACM Digital Library** e auxiliei na tabulação dos resultados brutos gerados no Passo 5.
* **Tempo dedicado:** ~3h

---

## 2. Documentação e Ata de Validação das Strings (Evidência Física)

Abaixo encontra-se o registro técnico (ata) da modelagem matemática das strings de busca, desenvolvidas para restringir os resultados estritamente à complexidade de algoritmos em computação gráfica, evitando artigos focados unicamente em direção de arte visual.

### Lógica Booleana Aplicada

**String 1 (Foco Geral no Comparativo Algorítmico):**
* **Operadores:** `("Ray tracing" OR "BVH") AND ("Rasterization" OR "Z-buffer") AND ("Complexity" OR "Performance")`
* **Justificativa da modelagem:** O operador `OR` agrupa as técnicas e suas respectivas estruturas de dados, enquanto o `AND` obriga a base de dados a cruzar as duas abordagens obrigatoriamente com métricas de desempenho. 
* **Base de aplicação principal:** IEEE Xplore.

**String 2 (Foco em Complexidade de Tempo e Custo):**
* **Operadores:** `("Real-time rendering") AND ("asymptotic complexity" OR "computational cost") AND ("Ray tracing")`
* **Justificativa da modelagem:** O uso das aspas exatas em `"Real-time rendering"` remove resultados de renderização offline (como cinema), focando a pesquisa no estresse computacional em tempo real exigido pelo projeto.
* **Base de aplicação principal:** Scopus.

**String 3 (Foco em Estruturas de Memória Espacial vs Matricial):**
* **Operadores:** `("Bounding Volume Hierarchy" OR "BVH") AND ("Z-buffer" OR "Rasterization") AND "Performance"`
* **Justificativa da modelagem:** Destinada especificamente à base da **ACM Digital Library** para capturar *papers* da SIGGRAPH detalhando a travessia de árvores na GPU contra a varredura linear do Z-buffer.
* **Execução (Passo 5):** A aplicação desta string na ACM DL retornou 134 resultados brutos em 16/09/2026.

---

## 3. Conclusão da Etapa

A estruturação algorítmica das strings garantiu a viabilidade da filtragem executada no Passo 6 e 7, reduzindo drasticamente o ruído bibliográfico (artigos de design visual) e isolando a literatura técnica voltada ao hardware e à matemática das estruturas.