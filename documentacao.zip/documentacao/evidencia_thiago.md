# Registro de Evidência de Contribuição Individual — Thiago de Luca Fernandes

**Curso / Disciplina:** Ciência da Computação / Computabilidade e Complexidade de Algoritmos  
**Projeto:** Análise Comparativa do Custo Computacional: Z-Buffer vs BVH (Ray Tracing)  
**Orientadora:** Andrea Ono Sakai  

---

## 1. Etapa (a) — Escolha do Tema

* **Papel / Atuação:** Definição do escopo algorítmico e delimitação do tema.
* **Descrição detalhada:** Estruturei a delimitação do tema introduzindo o comparativo técnico entre a varredura matricial (Z-buffer) e as estruturas de árvore espacial (BVH), elaborando a justificativa focada na complexidade de espaço e tempo, removendo abordagens focadas em qualidade visual.
* **Tempo dedicado:** ~7h
* **Evidência de versionamento:** Modificações consolidadas no arquivo `a_Escolha_do_Tema.md` e registradas no histórico de commits do repositório principal do GitHub.

---

## 2. Etapa (b) — Levantamento Bibliográfico

* **Passos em que atuou:** Passo 1, Passo 5 e Passo 7.
* **Tempo dedicado:** ~7h

### Detalhamento das Atividades por Passo:

* **Passo 1 — Pergunta de Pesquisa e Conceitos-chave:** Formulei a versão de trabalho do problema de pesquisa e estruturei a tabela de termos e sinônimos (PT/EN) para Z-buffer, BVH, rasterização e complexidade assintótica.
* **Passo 5 — Execução das Buscas:** Executei as queries de busca nas bases **IEEE Xplore** (String 1, resultando em 215 artigos) e **Scopus** (String 2, resultando em 82 artigos), computando a amostra bruta inicial.
* **Passo 7 — Triagem por Leitura Completa (2ª Filtragem):** Realizei a leitura crítica integral (introdução, metodologia e conclusão) dos 18 artigos pré-selecionados na primeira fase, aplicando os critérios de exclusão para eliminar trabalhos focados em fotorrealismo e TCCs, aprovando o conjunto definitivo de 5 artigos científicos revisados por pares.

---

## 3. Comprovação dos Artefatos de Busca (Zotero)

A comprovação prática da triagem e da leitura analítica da Etapa (b) foi estruturada no gerenciador de referências **Zotero** e exportada diretamente para o repositório do projeto.

### Artefatos Gerados:
1. **Planilha de Triagem `.csv`:** O arquivo físico `referencias/triagem_final_zotero.csv` contém todos os metadados (Título, Autores, Ano, Periódico, DOI, Volume, Páginas e Abstract) dos artigos aprovados no Passo 7.
2. **Notas Teóricas de Avaliação do BVH:** Registraram-se notas analíticas na biblioteca do Zotero detalhando o gargalo de memória e o comportamento assintótico $O(\log N)$ da estrutura espacial Bounding Volume Hierarchy (BVH) em comparação com o Z-buffer $O(W \times H)$.

---

## 4. Resumo de Participação Individual

| Etapa / Passo | Descrição da Contribuição | Status |
|---|---|---|
| Etapa A (Tema) | Delimitação técnica do tema e justificativa de complexidade | Concluído |
| Etapa B - Passo 1 | Definição da pergunta de pesquisa e conceitos-chave | Concluído |
| Etapa B - Passo 5 | Execução de buscas no IEEE Xplore e Scopus | Concluído |
| Etapa B - Passo 7 | Leitura completa, filtragem de 18 para 5 artigos e notas no Zotero | Concluído |